// Task 1

const students = [
    { name: 'Saghar', age: 22, score: 45 },
    { name: 'Qamar', age: 20, score: 75 },
    { name: 'Shams', age: 23, score: 60 },
    { name: 'Maher', age: 21, score: 30 },
    { name: 'Farhan', age: 24, score: 50 },
];

// let students_scored_less_than_50 = students.filter(i=>i.score<50);

// console.log(students_scored_less_than_50);

// let remaining_students = students.map((i)=>i.name);

// console.log(remaining_students);

// let Shams_record = students.find(i=>i.name === "Shams");

// console.log(Shams_record);

// let name_end_with_r = students.some(i => i.name.at(-1) === "r");

// console.log(name_end_with_r);


// let total_score_by_all_students = students.reduce((acc, value) => acc += value.score,0);

// console.log(total_score_by_all_students);


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Task 2

// const square = x => x * x;
// const double = x => x * 2;

// const abc = (a, b) => x => b(a(x));

// const first_square_then_double = abc(square,double);

// // console.log(square(2));
// // console.log(double(10));

// console.log(first_square_then_double(3));

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Task 3

// const obj_calculator = {
//     value : 10,
//     multiply : function(a){
//         const product = (b) => this.value * b ;
//         product(a);
//     }
// }

// const c = obj_calculator.multiply(5);
// console.log(c);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





